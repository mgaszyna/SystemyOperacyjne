#include <iostream>

int main() {
    std::cout<<"Hello world";
    getchar();
    return 0;
}
